## ServerlessMailService

A lambda function to send emails by lambda invoke for dead simple client side forms.

### Client example

```javascript
import jwt from "jsonwebtoken";
import axios from "axios";

const formToken = item =>
  jwt
    .sign(
      formValues,
      "3F19cAcB85f8E06CD0ab4c9d17E782EdE7D77C022A4dF5b0688d526Dd6C9eF87"
    )
    .toString();

axios.post(`${YourLamdbaURL}`, formToken);
```
